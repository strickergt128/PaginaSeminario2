  $(document).ready(function(){
      $('.parallax').parallax();
    });
